import jdk.nashorn.internal.parser.JSONParser;
import net.sf.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 *
 */
public class ParserTest {

    Parser parser = new Parser();
    JSONObject before = null;
    JSONObject after = null;


    @Before
    public void setup() throws Exception {
        // TODO Load in test data from before.json and after.json

        JsonReader reader = new JsonReader();
        before = JsonReader.readJsonFile("src/test/resources/before.json");
        after = JsonReader.readJsonFile("src/test/resources/after.json");

    }

    @Test
    public void compareObjectTest(){
        CandidateMetadata beforeCmd = EntityFactory.jsonToEntityConvertor(before);
        CandidateMetadata afterCmd = EntityFactory.jsonToEntityConvertor(after);
        Diff diff = parser.compareObjects(beforeCmd,afterCmd);
        Assert.assertNotNull(diff);

    }

    @Test
    public void compareJSONSAndTakeJSONObjectDiff(){
       JSONObject diffJSON = parser.parse(before,after);
        System.out.println(diffJSON);
       Assert.assertNotNull(diffJSON);
    }









    // TODO Define tests here

}
