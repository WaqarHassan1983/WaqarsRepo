import java.util.List;
import java.util.Map;
import java.util.ArrayList;


public class Diff {


            /* This class is representing to carry the Diff.json files as data model/entity container  */

    private ArrayList<MetaDiff> meta;
    private CandidateDiff candidates;

    public List<MetaDiff> getMeta() {
        return meta;
    }

    public void setMeta(ArrayList<MetaDiff> meta) {
        this.meta = meta;
    }

    public CandidateDiff getCandidates() {
        return candidates;
    }

    public void setCandidates(CandidateDiff candidates) {
        this.candidates = candidates;
    }
}
