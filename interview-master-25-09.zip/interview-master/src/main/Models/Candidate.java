





public class Candidate {


    /* This class is representing to carry the before.json and after.json files as data model container  */



    private String id;
    private String candidateName;
    private String extraTime;

    public Candidate(String id, String candidateName, String extraTime) {
        this.id = id;
        this.candidateName = candidateName;
        this.extraTime = extraTime;
    }

    public String getId() {
        return id;
    }

    public String getCandidateName() {
        return candidateName;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setCandidateName(String candidateName) {
        this.candidateName = candidateName;
    }

    public void setExtraTime(String extraTime) {
        this.extraTime = extraTime;
    }

    public String getExtraTime() {
        return extraTime;

    }




}
