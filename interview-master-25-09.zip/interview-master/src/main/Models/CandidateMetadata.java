import java.util.List;

public class CandidateMetadata {
    /* This class is representing to carry the before.json and after.json files as data model/entity container  */


    private String id;
    private Metadata meta;
    private List<Candidate> candidates;

    public CandidateMetadata() {

    }

    public CandidateMetadata(String id, Metadata meta, List<Candidate> candidates) {
        this.id = id;
        this.meta = meta;
        this.candidates = candidates;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Metadata getMeta() {
        return meta;
    }

    public void setMeta(Metadata meta) {
        this.meta = meta;
    }

    public List<Candidate> getCandidates() {
        return candidates;
    }

    public void setCandidates(List<Candidate> candidates) {
        this.candidates = candidates;
    }
}
