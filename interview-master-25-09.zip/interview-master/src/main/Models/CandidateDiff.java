import java.util.Map;

public class CandidateDiff {

            /* This class is representing to carry the Diff.json file as data model/entity container */

    private Map edited;
    private Map added;
    private Map removed;

    public Map getEdited() {
        return edited;
    }

    public void setEdited(Map edited) {
        this.edited = edited;
    }

    public Map getAdded() {
        return added;
    }

    public void setAdded(Map added) {
        this.added = added;
    }

    public Map getRemoved() {
        return removed;
    }

    public void setRemoved(Map removed) {
        this.removed = removed;
    }
}
