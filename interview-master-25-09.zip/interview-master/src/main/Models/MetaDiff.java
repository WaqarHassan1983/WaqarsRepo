import java.util.List;

public class MetaDiff{

            /* This class is representing to carry the Diff.json files as data model/entity container  */

    private String field;
    private String before;
    private String after;

    public MetaDiff(String title, String before, String after) {
        this.field = title;
        this.before = before;
        this.after = after;
    }

    public String getTitle() {
        return field;
    }

    public void setTitle(String title) {
        this.field = title;
    }

    public String getBefore() {
        return before;
    }

    public void setBefore(String before) {
        this.before = before;
    }

    public String getAfter() {
        return after;
    }

    public void setAfter(String after) {
        this.after = after;
    }
}