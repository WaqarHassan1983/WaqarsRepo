import net.sf.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.time.*;

/**
 *
 */
public class Parser {


    /*
    * This is the main entry point of the whole program from where code it actcually begin. This method take two JSONObjects of before and after JSON files and return the
    * Diff(DataModel of Diff.json file) JSON object.
    * */
    public JSONObject parse(JSONObject before, JSONObject after) {

        CandidateMetadata beforeCmd = EntityFactory.jsonToEntityConvertor(before);
        CandidateMetadata afterCmd = EntityFactory.jsonToEntityConvertor(after);
        Diff diffObjAfterComparsion = compareObjects(beforeCmd,afterCmd);
        JSONObject jsonDiff = EntityFactory.entityToJSONObject(diffObjAfterComparsion);

        // TODO Implement this
        return jsonDiff;
    }


    /*
    * This method actually takes two parameters of JSON (Before and After) datamodel/entity objects, and return the comparables Diff(Datamodel/entity of Diff.json file) object.
    * */
    public Diff compareObjects (CandidateMetadata before , CandidateMetadata after)
    {
        Diff diff = new Diff();

        if(before.getId().equals(after.getId()))
        {

            if(!comparator(before.getMeta().getTitle(),after.getMeta().getTitle())
                    || !comparator(before.getMeta().getStartTime(),after.getMeta().getStartTime())
                    || !comparator(before.getMeta().getEndTime(),after.getMeta().getEndTime()))
            {
                diff.setMeta(new ArrayList<MetaDiff>());

                if(!comparator(before.getMeta().getTitle(),after.getMeta().getTitle()))
               {
                   diff.getMeta().add(new MetaDiff("title",before.getMeta().getTitle(),after.getMeta().getTitle()));
               }

                if(!comparator(before.getMeta().getStartTime(),after.getMeta().getStartTime()))
                {
                    diff.getMeta().add(new MetaDiff("startTime",before.getMeta().getStartTime(),after.getMeta().getStartTime()));
                }

                if(!comparator(before.getMeta().getEndTime(),after.getMeta().getEndTime()))
                {
                    diff.getMeta().add(new MetaDiff("endTime",before.getMeta().getEndTime(),after.getMeta().getEndTime()));
                }
            }

            CandidateDiff  candidateDiff = new CandidateDiff();

            candidateDiff.setEdited(new HashMap());
            candidateDiff.setRemoved(new HashMap());
            candidateDiff.setAdded(new HashMap());

            for(Candidate beforeCandidateList: before.getCandidates())
            {
                boolean removed=true;

                for(Candidate afterCandidateList: after.getCandidates())
                {
                    if(comparator(beforeCandidateList.getId(),afterCandidateList.getId()))
                    {
                        removed=false;

                        if(!comparator(beforeCandidateList.getCandidateName(),afterCandidateList.getCandidateName())
                                || !comparator(beforeCandidateList.getExtraTime(),afterCandidateList.getExtraTime()))
                        {
                            candidateDiff.getEdited().put(beforeCandidateList.getId(),beforeCandidateList.getId());
                        }
                    }
                }

                if(removed==true)
                {
                    candidateDiff.getRemoved().put(beforeCandidateList.getId(),beforeCandidateList.getId());
                }
            }

            for(Candidate afterCandidateList: after.getCandidates())
            {
                boolean exists=false;

                for(Candidate beforeCandidateList: before.getCandidates())
                {
                    if(comparator(beforeCandidateList.getId(),afterCandidateList.getId()))
                    {
                        exists=true;
                    }


                }

                if(exists==false)
                {
                    candidateDiff.getAdded().put(afterCandidateList.getId(),afterCandidateList.getId());
                }
            }
            diff.setCandidates(candidateDiff);

        }
        return diff;
    }

    /*comparing those values into Before and after json files*/
    private boolean comparator (String before, String after)
    {
        return before.equals(after);

    }


}
