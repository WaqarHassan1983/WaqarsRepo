import net.sf.json.JSONObject;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.TimeZone;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.text.DateFormat;

public class MainDateFormat {

     /*                                              IMPORTANT NOTE

     THIS METHOD INTO THIS CLASS, I TRIED TO WRITE JUST TO HANDLE SET THE TIMEZONE OF THE GIVEN DATES.

       * The data for date appears to be incompatible with the timezone conversion. It seems as whenever I tend to use timezone
       * available on the default data structures, timezone conversion is performed without any problem. However parsed
       * objects from string doesn't seem to have enough details for timezone conversion.
       *
       *
        *                                            POSSIBLE SOULTION COULD BE
        *
        *   I have tried many possibilities and spent around 5 hours to fix this issue but unfortunately not successful, I think, If I try to fetch the incompitable available
        *   dates into before and after json files and set them one by one manually into Calender object and then try to set the Timezone. It may work out.
        *   Unfortunately, because time constraints I cant undle until now. But if you allow some more time to fix this. I could try once more time.

        *
         *
       *
       *
       * */


    public static void main(final String[] args) throws ParseException {
        Calendar calendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));

        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        formatter.setTimeZone(TimeZone.getTimeZone("UTC"));



        // formatter.setTimeZone(TimeZone.getTimeZone("GMT+2"));

        Date date = formatter.parse("2016-01-20T10:00:00Z");
        calendar.set(date.getYear(),date.getMonth(),date.getDate(),date.getHours(),date.getMinutes(),date.getSeconds());


        //  calendar.setTime(date);

        String osloTime = formatter.format(calendar.getTime());

        System.out.println("using calendar "+ osloTime);


    }
}
