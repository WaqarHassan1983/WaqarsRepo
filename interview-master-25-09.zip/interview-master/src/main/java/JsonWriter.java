import net.sf.json.JSONObject;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.FileOutputStream;


public class JsonWriter {

    /*Deprecated class*/

    public static void writeJson(JSONObject jsonDiff) throws Exception
    {
        ObjectOutputStream outputStream =new ObjectOutputStream(new FileOutputStream("../resources/diffTest.json"));
        outputStream.writeObject(jsonDiff);
        outputStream.flush();
        outputStream.close();

    }
}
