import net.sf.json.JSONObject;
import net.sf.json.JSONSerializer;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import org.apache.commons.io.IOUtils;

public class JsonReader {

    /* This method read the from the path of Json files such as (before, after,diff) and return the JSONObject.
    * */
    public static JSONObject readJsonFile(String path) throws Exception
    {
        InputStream is = new FileInputStream(path);
        String jsonTxt = IOUtils.toString(is);
        //System.out.println(jsonTxt);
        JSONObject json = (JSONObject) JSONSerializer.toJSON( jsonTxt );

        return json;
    }
}
