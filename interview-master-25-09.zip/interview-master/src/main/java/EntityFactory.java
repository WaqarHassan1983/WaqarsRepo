import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class EntityFactory {
/*
*  jsonToEntityConvertor method actually get as parameter JSONobjects of both JSON files(before.json and after.json) and return
*  CandidateMetadata object, use as entity data model to carry the before and after json files data.
*
* */

    public static CandidateMetadata jsonToEntityConvertor(JSONObject jsonObj)
    {
        CandidateMetadata candidateMd = new CandidateMetadata();

        candidateMd.setId(jsonObj.getString("id"));

        JSONObject meta = jsonObj.getJSONObject("meta");
        candidateMd.setMeta(new Metadata(meta.getString("title"),meta.getString("startTime"),meta.getString("endTime")));


        candidateMd.setCandidates(new ArrayList<Candidate>());
        List<JSONObject> candidates = jsonObj.getJSONArray("candidates");
        for(JSONObject candidate:candidates)
        {

            candidateMd.getCandidates().add(new Candidate(candidate.getString("id"),candidate.getString("candidateName"),candidate.getString("extraTime")));
        }

        return candidateMd;

    }

  /*
  *     This method 'entityToJSONObject' takes a parameter of Diff data model object carry all the data Diff.json files contains,
  *     and return the Diff.json file as JSONObject.
  * */

    public static JSONObject entityToJSONObject(Diff diffObject)
    {

        JSONObject json = new JSONObject();

        JSONArray meta = new JSONArray();
        for(MetaDiff metaDiff: diffObject.getMeta())
        {
            JSONObject metaObj = new JSONObject();
            metaObj.put("filed",metaDiff.getTitle());
            metaObj.put("before",metaDiff.getBefore());
            metaObj.put("after",metaDiff.getAfter());
            meta.add(metaObj);

        }

        json.put("meta",meta);

        JSONObject candidates = new JSONObject();

        JSONArray edited = new JSONArray();
        for (Object key : diffObject.getCandidates().getEdited().keySet()) {
             String keyset = diffObject.getCandidates().getEdited().get(key).toString();
            JSONObject metaObj = new JSONObject();
            metaObj.put("id",keyset);
            edited.add(metaObj);

        }

        candidates.put("edited",edited);

        JSONArray added = new JSONArray();
        for (Object key : diffObject.getCandidates().getAdded().keySet()) {
            String keyset = diffObject.getCandidates().getAdded().get(key).toString();
            JSONObject metaObj = new JSONObject();
            metaObj.put("id",keyset);
            added.add(metaObj);

        }

        candidates.put("added",added);


        JSONArray removed = new JSONArray();
        for (Object key : diffObject.getCandidates().getRemoved().keySet()) {
            String keyset = diffObject.getCandidates().getRemoved().get(key).toString();
            JSONObject metaObj = new JSONObject();
            metaObj.put("id",keyset);
            removed.add(metaObj);

        }
        candidates.put("removed",removed);

        json.put("candidates",candidates);



        return json;
    }
}
